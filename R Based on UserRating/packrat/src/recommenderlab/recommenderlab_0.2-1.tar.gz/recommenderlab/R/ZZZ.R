## seal registry
recommenderRegistry$seal_entries()
